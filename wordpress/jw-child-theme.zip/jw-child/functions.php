<?php
define( 'CHILD_THEME_URI', get_stylesheet_directory_uri() );
define( 'WHITE_LABEL', false );
define( 'STATIC_IN_CHILD', false );

add_action( 'wp_enqueue_scripts', 'mfnch_enqueue_styles', 101 );
function mfnch_enqueue_styles() {
  wp_enqueue_style( 'style', get_template_directory_uri() . '/style.css' );
  if ( is_rtl() ) { wp_enqueue_style( 'mfn-rtl', get_template_directory_uri() . '/rtl.css' ); }
  wp_enqueue_style( 'mfn-child-style', get_stylesheet_directory_uri() . '/style.css' );
}

add_action( 'after_setup_theme', 'mfnch_textdomain' );
function mfnch_textdomain() {
  load_child_theme_textdomain( 'betheme', get_stylesheet_directory() . '/languages' );
  load_child_theme_textdomain( 'mfn-opts', get_stylesheet_directory() . '/languages' );
}
